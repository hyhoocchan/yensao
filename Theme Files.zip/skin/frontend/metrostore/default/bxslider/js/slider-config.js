


jQuery(function(j$) {

j$('.slider3').bxSlider({
    slideWidth: 1200,
    minSlides: 1,
    maxSlides: 4,
    moveSlides: 1,
    slideMargin: 0,
    pager: false,
    infiniteLoop: false,
    hideControlOnEnd: true
});


j$('.slider4').bxSlider({
    slideWidth: 1200,
    minSlides: 1,
    maxSlides: 4,
    moveSlides: 1,
    slideMargin: 0,
    pager: false,
    infiniteLoop: false,
    hideControlOnEnd: true
});



j$('.slider5').bxSlider({
    slideWidth: 1200,
    minSlides: 1,
    maxSlides: 4,
    moveSlides: 1,
    slideMargin: 20,
    pager: false,
    infiniteLoop: false,
    hideControlOnEnd: true
});

j$('.slider6').bxSlider({
    slideWidth: 86,
    minSlides: 1,
    maxSlides: 4,
    moveSlides: 1,
    slideMargin: 9,
    pager: false,
    infiniteLoop: false,
    hideControlOnEnd: true
});


  
  
});