<?php
class Magehouse_Slider_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 